package guia15ejercicio1;

import java.util.Collection;
import tienda.entidades.Fabricante;
import tienda.entidades.Producto;
import tienda.persistencia.FabricanteDAO;
import tienda.persistencia.ProductoDAO;
import tienda.servicios.FabricanteService;
import tienda.servicios.ProductoService;

/**
 *
 * @author Sebastián A. Petrini
 */
public class Guia15Ejercicio1
{

    public static void main(String[] args) throws Exception
    {
        Collection<Fabricante> ListaFabricantes;
        FabricanteService fS = new FabricanteService();
        FabricanteDAO fD = new FabricanteDAO();
        Collection<Producto> ListaProductos;
        ProductoDAO pD = new ProductoDAO();
        ProductoService pS = new ProductoService();

        /*ListaFabricantes = fD.listarFabricante();
        for (Fabricante Fabricante : ListaFabricantes)
        {
            System.out.println("Código: " + Fabricante.getCodigo() + "   Nombre: " + Fabricante.getNombre());
        }
        /*Fabricante f = fS.crearFabricante();
        fD.guardarFabricante(f);
        System.out.println("----------------------------"
                + "");
        ListaFabricantes = fD.listarFabricante();
        for (Fabricante Fabricante : ListaFabricantes)
        {
            System.out.println("Código: " + Fabricante.getCodigo() + "   Nombre: " + Fabricante.getNombre());
        }*/

        ListaProductos = pD.listarProducto();
        
        for (Producto Producto : ListaProductos)
        {
            System.out.println("Codigo: " + Producto.getCodigo() 
                    + " Nombre: " + Producto.getNombre() 
                    + " Precio: " + Producto.getPrecio() 
                    + " Codigo fabricante: " + Producto.getCodigoFabricante());
        }
        
        

    }

}
