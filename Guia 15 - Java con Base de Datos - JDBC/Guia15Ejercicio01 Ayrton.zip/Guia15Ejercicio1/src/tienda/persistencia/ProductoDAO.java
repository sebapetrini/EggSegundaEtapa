package tienda.persistencia;

import java.util.ArrayList;
import java.util.Collection;
import tienda.entidades.Producto;

/**
 *
 * @author Sebastián A. Petrini
 */
public class ProductoDAO extends DAO
{

    public void guardarProducto(Producto p) throws Exception
    {
        try
        {
            if (p == null)
            {
                throw new Exception("Debe indicar un producto");
            }
            String sql = "INSERT INTO producto (codigo, nombre, precio, codigo_fabricante) "
                    + "VALUES ( '" + p.getCodigo() + "' , '" + p.getNombre() + "' , '" + p.getPrecio() + "' , '" + p.getCodigoFabricante() + "');";
            System.out.println(sql);
            insertarModificarEliminar(sql);
        } catch (Exception e)
        {
            throw e;
        } finally
        {
            desconectarBase();
        }
    }

    public void eliminarProducto(int codigo) throws Exception
    {
        try
        {
            String sql = "DELETE FROM producto WHERE codigo = " + codigo + "";
            insertarModificarEliminar(sql);
        } catch (Exception e)
        {
            throw e;
        } finally
        {
            desconectarBase();
        }
    }

    public Collection<Producto> listarProducto() throws Exception
    {
        try
        {
            String sql = "SELECT * FROM producto ";
            consultarBase(sql);
            Producto p = null;
            Collection<Producto> pl = new ArrayList();
            while (resultado.next())
            {
                p = new Producto();
                p.setCodigo(resultado.getInt(1));
                p.setNombre(resultado.getString(2));
                p.setPrecio(resultado.getDouble(3));
                p.setCodigoFabricante(resultado.getInt("codigo_fabricante"));
                pl.add(p);
            }
            desconectarBase();
            return pl;
        } catch (Exception e)
        {
            e.printStackTrace();
            desconectarBase();
            throw e;
        }
    }
}
