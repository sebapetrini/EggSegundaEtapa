

package tienda.servicios;

import java.util.Scanner;
import tienda.entidades.Producto;

/**
 *
 * @author Sebastián A. Petrini
 */

public class ProductoService {
    
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
        public Producto crearProducto(){
        System.out.print("Ingrese el código del Producto: ");
        int codigo = leer.nextInt();
        System.out.print("Ingrese el nombre del Producto: ");
        String nombre = leer.next();
        System.out.println("Ingrese el precio");
        double precio = leer.nextDouble();
        System.out.println("Ingrese el codigo del fabricante");
        int codigoFabricante = leer.nextInt();
        
        return new Producto(codigo, nombre, precio, codigoFabricante);
    }
    
}
