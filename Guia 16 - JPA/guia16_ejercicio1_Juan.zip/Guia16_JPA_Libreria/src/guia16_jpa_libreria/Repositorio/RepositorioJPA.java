/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guia16_jpa_libreria.Repositorio;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Juan \ Marcela XD
 */
public class RepositorioJPA<T> {

    protected EntityManagerFactory emf;
    protected EntityManager em;

    public RepositorioJPA() {
        this.emf = Persistence.createEntityManagerFactory("guia16_jpa_libreria");
        this.em = emf.createEntityManager();
    }

    protected void conect() {
        if (!em.isOpen()) {
            em = emf.createEntityManager();
        }
    }

    protected void disconect() {
        if (em.isOpen()) {
            em.close();
        }
    }

    protected void create(T object) {
        try {
            conect();
            em.getTransaction().begin();
            em.persist(object);
            em.getTransaction().commit();
            disconect();
        } catch (Exception e) {
            System.out.println("ERROR al crear el objeto");
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        }
    }

    protected void update(T object) {
        try {
            conect();
            em.getTransaction().begin();
            em.merge(object);
            em.getTransaction().commit();
            disconect();
        } catch (Exception e) {
            System.out.println("ERROR al actualizar el objeto");
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        } finally {
            disconect();
        }

    }

    protected void delete(T object) {
        try {
            conect();
            em.getTransaction().begin();
            em.remove(object);
            em.getTransaction().commit();
            disconect();
        } catch (Exception e) {
            System.out.println("ERROR al eliminar el objeto");
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        } finally {
            disconect();
        }
    }
}
