/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package guia16_jpa_libreria.Repositorio;

import guia16_jpa_libreria.entidades.Editorial;
import java.util.List;

/**
 *
 * @author Juan \ Marcela XD
 */
public class EditorialRepositorio extends RepositorioJPA<Editorial> {

    public EditorialRepositorio() {
        super();
    }
    
    public void crear(Editorial editorial) {
        super.create(editorial);
    }
    
    public void editar(Editorial editorial) {
        super.update(editorial);
    }
    
    public void borrar(Integer id) {
        Editorial editorial = buscarPorId(id);
        super.delete(editorial);
    }
    
    public Editorial buscarPorId(Integer id) {   // Buscar Autor por id
        super.conect();
        Editorial editorial = em.find(Editorial.class, id);
        super.disconect();
        return editorial;
    }
    
    public List<Editorial> listarAutores() {
        super.conect();
        List<Editorial> editorial = em.createNamedQuery("Editorial.findAll", Editorial.class).getResultList(); // El query "Editorial.findAll" est� declarado en la entidad de Autor
        super.disconect();
        return editorial;
    }
    

}
