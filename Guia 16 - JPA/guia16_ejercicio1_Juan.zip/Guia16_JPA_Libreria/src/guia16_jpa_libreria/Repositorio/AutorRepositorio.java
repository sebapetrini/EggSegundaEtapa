/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package guia16_jpa_libreria.Repositorio;

import guia16_jpa_libreria.entidades.Autor;
import java.util.List;

/**
 *
 * @author Juan \ Marcela XD
 */
public class AutorRepositorio extends RepositorioJPA<Autor> {

    public AutorRepositorio() {
        super();
    }

    public void crear(Autor autor) {
        super.create(autor);
    }
    
    public void editar(Autor autor) {
        super.update(autor);
    }
    
    public void borrar(Integer id) {
        Autor autor = buscarPorId(id);
        super.delete(autor);
    }
    
    public Autor buscarPorId(Integer id) {   // Buscar Autor por id
        super.conect();
        Autor autor = em.find(Autor.class, id);
        super.disconect();
        return autor;
    }
    
    /* Otra forma de buscar por ID
    public Autor findId(Integer id) {
        super.conect();
        Autor autor = em.createNamedQuery("Autor.findById", Autor.class).setParameter("id", id).getSingleResult();
        super.disconect();
        return autor;
    }
    */
    
    public List<Autor> buscarPorNombre(String nombre) {
        super.conect();
        List<Autor> autor = em.createQuery("SELECT a FROM Autor a WHERE a.nombre LIKE '%:nombre%'", Autor.class).setParameter("nombre", nombre).getResultList(); //en las createQuery se utiliza el texto no el NamedQuery
        super.disconect();
        return autor;
    }
    
    
    public List<Autor> listarAutores() {
        super.conect();
        List<Autor> autores = em.createNamedQuery("Autor.findAll", Autor.class).getResultList(); // El query "Autor.findAll" est� declarado en la entidad de Autor
        super.disconect();
        return autores;
    }
    
    
    
}
