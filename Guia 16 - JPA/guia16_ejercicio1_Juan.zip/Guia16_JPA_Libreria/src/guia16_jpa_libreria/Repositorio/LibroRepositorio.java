/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package guia16_jpa_libreria.Repositorio;

import guia16_jpa_libreria.entidades.Libro;
import java.util.List;

/**
 *
 * @author Juan \ Marcela XD
 */
public class LibroRepositorio extends RepositorioJPA<Libro> {

    public LibroRepositorio() {
        super();
    }

    public void crear(Libro libro) {
        super.create(libro);
    }
    
    public void editar(Libro libro) {
        super.update(libro);
    }
    
    public void borrar(Long isbn) {
        Libro libro = buscarPorISBN(isbn);
        super.delete(libro);
    }
    
    public Libro buscarPorISBN(Long isbn) {   // Buscar Autor por id
        super.conect();
        Libro libro = em.find(Libro.class, isbn);
        super.disconect();
        return libro;
    }
    
    public List<Libro> listarAutores() {
        super.conect();
        List<Libro> autores = em.createNamedQuery("Libro.findAll", Libro.class).getResultList(); // El query "Autor.findAll" est� declarado en la entidad de Autor
        super.disconect();
        return autores;
    }
}
