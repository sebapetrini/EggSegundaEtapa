/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package guia16_jpa_libreria.servicios;

import guia16_jpa_libreria.Repositorio.AutorRepositorio;
import guia16_jpa_libreria.entidades.Autor;
import java.util.Scanner;

/**
 *
 * @author Juan \ Marcela XD
 */
public class AutorServicio {
    
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    private AutorRepositorio ar = new AutorRepositorio();
    
    public void crearAutor() {
        
        System.out.println("Ingrese el nombre:");
        String name = leer.next();
        
        ar.crear(new Autor(name, Boolean.TRUE));
    }
    
}
