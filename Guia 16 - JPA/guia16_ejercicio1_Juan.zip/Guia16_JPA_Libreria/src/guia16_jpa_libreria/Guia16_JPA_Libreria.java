/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package guia16_jpa_libreria;

import guia16_jpa_libreria.servicios.MenuServicio;

/**
 *
 * @author Juan \ Marcela XD
 */
public class Guia16_JPA_Libreria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        MenuServicio ms = new MenuServicio();
        
        ms.menu();
    }

}
