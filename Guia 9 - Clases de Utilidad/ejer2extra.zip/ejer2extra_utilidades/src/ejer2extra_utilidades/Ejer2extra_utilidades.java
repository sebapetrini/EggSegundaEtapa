package ejer2extra_utilidades;
import entidades.Ahorcado;
import java.util.Scanner;
import servicio.ServicioAhorcado;

/**juego ahorcado:crear una clase ahorcado(como el juego), la cual debera 
 * contener como atributos, un vector con la palabra a buscar, la cantidad de 
 * letras encontradas y la cantidad jugadas maximas que puede realizar el usuario
 * Definir los siguientes metodos en ahorcado servicio.
 * 
 * a)Metodo crearJuego():le pide la palabra al usuario y cantidad de jugadas
 * maxima.Con la palabra del usuario, pone la longitud de la palabra como la 
 * longitud del vector.Despues ingresa la palabra en el vector, letra por letra,
 * quedando cada letra de la palabra en un indice del vector.Y tambien, guarda
 * la cantidad de jugadas maximas y el valor que ingreso el usuario.
 * 
 * b)Metodo longitud():muestra la longitud de la palabra que se debe encontrar.
 * Nota:buscar como se usa el vector.length.
 * 
 * c)Metodo buscar(letra):este metodo recibe una letra ingresada por el usuario
 * y muestre cuantas letras han sido encontradas y cuantas le faltan.Este metodo
 * ademas debera devolver true si la letra estaba y false si la letra no estaba
 * ya que, cada vez que se busque una letra que no este, se le restara uno a 
 * sus oportunidades.
 * 
 * d)Metodo intentos():para mostrar cuantas oportunidades le queda al jugador.
 * 
 * e)Metodo juego():el metodo juego se encargara de llamar todos los metodos
 * previamente mencionados e informara cuando el usuario descubra toda la 
 * palabra o se quede sin intentos.Este metodo se llamara en el main.
 */
public class Ejer2extra_utilidades {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
       ServicioAhorcado sa= new ServicioAhorcado();
       Ahorcado juego1 = sa.crearJuego();
       sa.juego(juego1);
       System.out.println("");
    }   
}

        
        
        
    


