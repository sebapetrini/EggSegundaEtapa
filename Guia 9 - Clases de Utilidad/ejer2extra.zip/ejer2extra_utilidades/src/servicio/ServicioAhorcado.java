package servicio;
import entidades.Ahorcado;
import java.util.Scanner;
/**
 */
public class ServicioAhorcado {
  
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    String letra;
    int cuantasVeces;
    boolean son;
   
    public Ahorcado crearJuego() {
        Ahorcado juego = new Ahorcado();
        System.out.println("INGRESE LA PALABRA A ADIVINAR:");
        String palabra = leer.next();
        String[] vector = new String[palabra.length()];
        for (int i = 0; i < vector.length; i++) {
            vector[i] = palabra.substring(i, i+1);  
        }
        juego.setPalabra(vector);
        System.out.println("Ingrese la Cantidad de Jugadas Máxima: ");
        juego.setCantidadJugadasMaximas(leer.nextInt());
        return juego;
    }
    
    public void longitud(Ahorcado juego) {
        System.out.println("La longitud de la Palabra a Buscar es de " + juego.getPalabra().length + " letras."); 
    } 
    
    public void buscarLetra(Ahorcado juego) {
        String[] vecAux = new String[juego.getPalabra().length];
        mostrarAvance(vecAux);
        do {
            cuantasVeces = 0;
            System.out.println("");
            System.out.println("Ingrese una Letra para saber si está en la Palabra.");
            letra = leer.next();
            for (int i = 0; i < juego.getPalabra().length; i++) {
                if (juego.getPalabra()[i].equalsIgnoreCase(letra)) {
                    cuantasVeces++;
                    vecAux[i] = juego.getPalabra()[i];
                } 
            }
            System.out.println("");
            if (cuantasVeces == 0) {
                System.out.println("La letra ingresada NO pertenece a la palabra.");
                letrasEncontradas(juego);
                intentos(juego);
            } else {
                System.out.println("La letra ingresada SI pertenece a la palabra.");
                letrasEncontradas(juego);
                intentos(juego);
            }
            System.out.println("");
            mostrarAvance(vecAux);
            System.out.println("=================================================");
        } while ((juego.getCantidadJugadasMaximas() > 0) && (juego.getPalabra().length!=Integer.valueOf(juego.getLetrasEncontradas())));
    }
    
    public boolean letrasEncontradas(Ahorcado juego) {
        
        if (cuantasVeces != 0) {
            juego.setLetrasEncontradas(juego.getLetrasEncontradas() + cuantasVeces);
            System.out.println("Número de Letras (encontradas/faltantes): (" + juego.getLetrasEncontradas() + "/"
                    + (juego.getPalabra().length - Integer.valueOf(juego.getLetrasEncontradas())) + ")");
           son =  true;
        } else {
            System.out.println("Número de Letras (encontradas/faltantes): (" +Integer.valueOf (juego.getLetrasEncontradas()) + "/"
            + (juego.getPalabra().length - Integer.valueOf (juego.getLetrasEncontradas())) + ")");
            son = false;
        }
        return son;
    }
    
    public void intentos(Ahorcado juego) {
        if (son!=true) {
            juego.setCantidadJugadasMaximas(juego.getCantidadJugadasMaximas()-1); 
        }
        System.out.println("Número de Oportunidades Restantes: "+juego.getCantidadJugadasMaximas());
    }
    
    public void juego(Ahorcado juego) {
        
        longitud(juego);
        System.out.println("");
        buscarLetra(juego);
        System.out.println("");
        System.out.println("imprima "+Integer.valueOf(juego.getLetrasEncontradas()));
        if (juego.getPalabra().length == Integer.valueOf(juego.getLetrasEncontradas())) {
            
            System.out.println("Has GANADO!!! -- Descubriste la PALABRA!!!!");
        } else {
            System.out.println("Has PERDIDO -- Te has quedado SIN INTENTOS....");
        }
    }
    
    public void mostrarAvance(String[] vec) {
        for (int i = 0; i < vec.length; i++) {
            if (vec[i]== null) { 
                vec[i] = "_ ";
            }
            System.out.print(vec[i]+" ");
        }
        System.out.println("");
    }  
}
 