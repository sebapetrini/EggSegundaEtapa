package entidades;
/**
 */
public class Ahorcado {
    private int letrasEncontradas;
    private int cantidadJugadasMaximas;
    private String[]palabra;

    public Ahorcado() {
    }

    public Ahorcado(int letrasEncontradas, int cantidadJugadasMaximas, String[] palabra) {
        this.letrasEncontradas = letrasEncontradas;
        this.cantidadJugadasMaximas = cantidadJugadasMaximas;
        this.palabra = palabra;
    }

    public int getLetrasEncontradas() {
        return letrasEncontradas;
    }

    public void setLetrasEncontradas(int letrasEncontradas) {
        this.letrasEncontradas = letrasEncontradas;
    }

    public int getCantidadJugadasMaximas() {
        return cantidadJugadasMaximas;
    }

    public void setCantidadJugadasMaximas(int cantidadJugadasMaximas) {
        this.cantidadJugadasMaximas = cantidadJugadasMaximas;
    }

    public String[] getPalabra() {
        return palabra;
    }

    public void setPalabra(String[] palabra) {
        this.palabra = palabra;
    }
}

    