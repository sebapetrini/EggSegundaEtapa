package com.petrini.demoNBA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoNbaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoNbaApplication.class, args);
	}

}
