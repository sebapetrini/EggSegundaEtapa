package com.petrini.demoNBA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoNbaApplicationTests {

	@Test
	void contextLoads() {
	}

}
