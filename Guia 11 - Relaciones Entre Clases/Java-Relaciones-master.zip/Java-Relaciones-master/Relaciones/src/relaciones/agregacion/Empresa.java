package relaciones.agregacion;

import relaciones.agregacion.Cliente;
import java.util.List;

public class Empresa {

    private List<Cliente> clientes;
    
}
