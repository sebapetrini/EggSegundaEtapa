package relaciones.agregacion;

public class Cliente {

}
