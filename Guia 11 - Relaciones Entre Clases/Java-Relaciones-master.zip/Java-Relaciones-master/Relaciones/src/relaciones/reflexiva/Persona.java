package relaciones.reflexiva;

import java.util.List;

public class Persona {

    private List<Persona> amigos;
    
}
