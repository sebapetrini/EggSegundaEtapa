package relaciones.reflexiva;

public class Nodo {

    private String value;
    private Nodo next;
    
}
