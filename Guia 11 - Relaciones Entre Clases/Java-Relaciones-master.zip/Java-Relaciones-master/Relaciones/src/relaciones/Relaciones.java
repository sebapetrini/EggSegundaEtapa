package relaciones;

public class Relaciones {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
