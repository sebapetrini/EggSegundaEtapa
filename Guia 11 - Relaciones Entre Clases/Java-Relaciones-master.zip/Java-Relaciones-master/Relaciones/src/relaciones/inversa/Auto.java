package relaciones.inversa;

public class Auto {

    private Persona propietario;
    
}
