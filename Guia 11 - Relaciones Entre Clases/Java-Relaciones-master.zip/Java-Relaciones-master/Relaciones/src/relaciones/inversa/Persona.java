package relaciones.inversa;

import java.util.List;

public class Persona {

    private List<Auto> autos;
    
}
