package relaciones.composicion;

public class Empleado {

    //Attr
    
}
