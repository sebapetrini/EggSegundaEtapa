package relaciones.composicion;

import java.util.List;

public class Empresa {

    private List<Empleado> empleados;
    
}
