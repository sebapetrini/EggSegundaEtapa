
export const obtenerPersonajes = async() => {

    const response = await fetch("https://rickandmortyapi.com/api/character");
    
    const data = await response.json();

    const datosPersonaje = data.results.slice(0,20).map((personaje) => ({name: personaje.name, image: personaje.image}));

    return datosPersonaje;

}

