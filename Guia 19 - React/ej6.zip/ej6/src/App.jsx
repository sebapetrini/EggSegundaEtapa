import './App.css'
import ListaPersonajes from './components/Componente'

function App() {

  return (
    <>
      
      <ListaPersonajes/>

    </>
  )
}

export default App
