import React, { useEffect, useState } from "react";
import { obtenerPersonajes } from "../services/ComponenteService";

export default function ListaPersonajes(){

    const [personajes, setPersonajes] = useState([]);
    
    useEffect(() => {

        const fetchData = async() => {

            const data = await obtenerPersonajes();

            setPersonajes(data);

        };

        fetchData();

    },[]);

    return (

        <div className="divComponente">
                <h3>Personajes de RyM</h3>
                <ul>
                    {personajes.map((personaje) => (<li key={personaje.id}><img src={personaje.image}/>Nombre: {personaje.name}</li>))}
                    
                </ul>
        </div>
    )

}
