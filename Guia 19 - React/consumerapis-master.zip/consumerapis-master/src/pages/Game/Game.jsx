import Table from "../../components/table/table";


export default function Game() {

    return (
        <>
            <Table />
        </>
    );
}