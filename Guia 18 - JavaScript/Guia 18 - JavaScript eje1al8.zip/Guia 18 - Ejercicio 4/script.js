var carac = prompt("Ingrese S/N:")
if (carac.toUpperCase() == "S" || carac.toUpperCase() == "N")  
    var mensaje = `CORRECTO!!!!!!`;
else
    var mensaje = `INCORRECTO!!!!!!!`;
alert(mensaje);