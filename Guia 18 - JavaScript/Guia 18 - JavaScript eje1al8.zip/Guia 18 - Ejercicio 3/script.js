var edad = prompt("Ingrese su edad: ");
if (edad > 18)  
    var mensaje = `Eres mayor de edad...`;
else
    var mensaje = `Eres menor de edad...`;
alert(mensaje);