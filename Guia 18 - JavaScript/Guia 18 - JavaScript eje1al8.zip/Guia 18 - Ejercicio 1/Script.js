var dia = prompt("¿como está el día de hoy? (Soleado, nublado, lloviendo)");
var mensaje = `El día de hoy está:
${dia}`;
alert(mensaje);