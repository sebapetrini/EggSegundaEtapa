<h1>Bienvenidos a JavaScript!</h1>
<p>Tendremos algunos archivos para explorar. Lo ideal sería descargarlos y analizarlos en la PC de cada uno</p>
<ul>
  <li><b>ejemplosJavaScript.js</b> tiene ejemplos del lenguaje propiamenente</li>
  <li><b>ejemplosJavaScriptUtilizandoDOM.js</b> tiene ejemplos de cómo modificar el DOM</li>
  <li><b>index.html</b> es la base que vamos a modificar a partir del archivo JS</li>
  <li><b>style.css</b> es el archivo de estilos</li>
</ul>
